import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tflite_image_classification/loadingPage1.dart';
import 'package:tflite_image_classification/loadingPage2.dart';
import "signup.dart";
import 'package:flutter/material.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import "homescreen.dart";
import 'package:get/get.dart';


var uid_check;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _HomepageState();
}

class _HomepageState extends State<HomePage>{
  Future<FirebaseApp> _initilizeFirebase() async
  {
    print("init");
    FirebaseApp firebaseApp = await Firebase.initializeApp();
    return firebaseApp;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: _initilizeFirebase(),
        builder: (context,snapshot){
          if(snapshot.connectionState==ConnectionState.done)
            {
              return LoginScreen();
            }
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();

}
class _LoginScreenState extends State<LoginScreen>{


  Future<User?> loginUsingEmailPassword({required String email, required String password,required BuildContext context}) async{

  FirebaseAuth auth =  FirebaseAuth.instance;
  User? user;

  try{
    UserCredential userCredential = await auth.signInWithEmailAndPassword(email: email, password: password);
    user = userCredential.user;

    user = auth.currentUser;

    uid_check = user?.uid;
    // Map userProfileData = {'username':''};

    var response = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo:user?.uid)
        .get();
    // print(response.docs[0]['cp_check']);
    if(response.docs[0]['cp_check']!=1)
      {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Enter Valid Email or Password"),
          backgroundColor: Color(0xff8c54fb),

        ));
        user = null;
        return user;
      }
    print(uid_check);

  } on FirebaseAuthException catch(e){
    if(e.code =="user-not-found"){
      print("no user found for that email");
      }

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Enter Valid Email or Password"),
      backgroundColor: Color(0xff8c54fb),

    ));

  }

  return user;


  }


  @override
  Widget build(BuildContext context)
  {
    TextEditingController _emailController = TextEditingController();
    TextEditingController _passwordController = TextEditingController();

    return Scaffold(
      body:SingleChildScrollView(
        child:Column(
          children: [
            Container(
              height: 300,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(120),bottomRight: Radius.circular(0)),
                color:Color(0xffaabbcc),
                gradient: LinearGradient(
                    colors:[new Color(0xffe4d6fb),(new Color(0xffe4d6fb))],
                    begin:Alignment.topRight,
                    end: Alignment.bottomLeft
                ),

              ),
              child: Center(
                  child: Column(
                    mainAxisAlignment:MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment:CrossAxisAlignment.center,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top:50),
                        child: Image.asset("assets/images/myLogo1.png"),
                        height: 250,
                        width: 250,
                      ),
                    ],
                  )
              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 20,right: 20,top: 70),
              padding: const EdgeInsets.only(left:15),
              decoration: BoxDecoration(
                  borderRadius:BorderRadius.circular(50),
                  border: Border.all(color: Color(0xff8c54fb),width: 0.5),

                  color: Color(0xffe4d6fb)
              ),
              alignment:Alignment.center,
              child:  TextField(
                controller: _emailController,
                  cursorColor:Color(0xfff2467),
                  cursorHeight: 20,
                  decoration:const InputDecoration(
                    icon: Icon(
                      Icons.email,
                      color: Color(0xff8c54fb),

                    ),
                    hintText: "Enter the mail",
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,

                  )

              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 20,right: 20,top: 20),
              padding: const EdgeInsets.only(left:15),

              decoration: BoxDecoration(
                  borderRadius:BorderRadius.circular(50),
                  border: Border.all(color: Color(0xff8c54fb),width: 0.5),
                  color: Color(0xffe4d6fb),
              ),
              alignment:Alignment.center,
              child: TextField(
                controller: _passwordController,
                  obscureText: true,
                  cursorColor:Color(0xfff2467),
                  decoration:const InputDecoration(
                    icon: Icon(
                      Icons.vpn_key,
                      color: Color(0xff8c54fb),
                    ),
                    hintText: "Password",
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,

                  )

              ),
            ),
            Container(
              margin: const EdgeInsets.only(top:20,right: 20),
              alignment: Alignment.centerRight,
              child: GestureDetector(
                child: const Text("Forget password?"),
                onTap: ()=>{

                },
              ),
            ),
            Container(
              width: 180,
              margin: EdgeInsets.only(top: 50),

              child: RawMaterialButton(

                fillColor: const Color(0xff7445ce),
                elevation: 15,
                padding: EdgeInsets.symmetric(vertical: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50.0)),
                onPressed: ()async{
                      // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoadingScreen1()));
                  //

                    User?user = await loginUsingEmailPassword(email: _emailController.text, password: _passwordController.text, context: context);
                  // print(user);
                  if(user!=null)
                    {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const LoadingScreen1()));
                    }

                },
                child: const Text(
                  "LogIn",
                  style: TextStyle(
                    color:Colors.white,
                  ),
                ),
              ),
            ),

            Container(
              margin: const EdgeInsets.only(top:15),
              child: Row(
                mainAxisAlignment:MainAxisAlignment.center,
                children: [
                  const Text("Don't have Account - "),
                  GestureDetector(
                    onTap: ()=>{
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => RegistrationScreen()
                      ))
                    },
                    child:const Text(
                      "Sign up",
                      style: TextStyle(
                        color:Color(0xff8c54fb),
                      ),
                    ),

                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
