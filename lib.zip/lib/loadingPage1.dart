import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:tflite_image_classification/homescreen.dart';
import 'login.dart';
import 'package:tflite_image_classification/login.dart';


class LoadingScreen1 extends StatefulWidget {
  // final String abc = "";
  const LoadingScreen1({Key? key}) : super(key: key);
  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<LoadingScreen1> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    startTime();
  }
  startTime() async {
    var duration = const Duration(seconds: 3);
    return Timer(duration, route);
  }

  route() {
    Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (context) =>  dashboard()
    ));
  }

  @override
  Widget build(BuildContext context) {
    return initWidget(context);
  }

  Widget initWidget(BuildContext context) {
    return const Scaffold(

      backgroundColor: Color(0xffe4d6fb),
      body: Center(
        child: SpinKitFadingCube(
          size: 50,
          color: Color(0xff8c54fb),
          duration: Duration(seconds: 2),
        ),
      ),
    );
  }
}