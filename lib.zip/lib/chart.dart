import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/signup.dart';
import 'package:tflite_image_classification/login.dart';
import 'package:tflite_image_classification/loadingPage1.dart';
import 'settings.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


Map userProfileData_B = {'Meal1':'','Meal2': '','Meal3':''};
Map userProfileData_L = {'Meal1':'','Meal2': '','Meal3':''};
Map userProfileData_D = {'Meal1':'','Meal2': '','Meal3':''};


class Chart extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<Chart> {

  FirebaseAuth auth =  FirebaseAuth.instance;
  User? user;



  Future<void> getUserProfileData() async
  {
    user = auth.currentUser;
    var response = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo:user?.uid)
        .get();


    userProfileData_B['Meal1'] = response.docs[0]['b_meal1'];
    userProfileData_B['Meal2'] = response.docs[0]['b_meal2'];
    userProfileData_B['Meal3'] = response.docs[0]['b_meal3'];

    userProfileData_L['Meal1'] = response.docs[0]['l_meal1'];
    userProfileData_L['Meal2'] = response.docs[0]['l_meal2'];
    userProfileData_L['Meal3'] = response.docs[0]['l_meal3'];

    userProfileData_D['Meal1'] = response.docs[0]['d_meal1'];
    userProfileData_D['Meal2'] = response.docs[0]['d_meal2'];
    userProfileData_D['Meal3'] = response.docs[0]['d_meal3'];

    try {

    }on FirebaseException catch(e){
      print(e);
    }catch(error){
      print(error);
    }



    setState((){
      return;
    });
  }
  Future<void> update_check_data() async
  {
    print(return_check_list.abc_l);

    if(return_check_list.abc_b['Meal1']==1.toString() && return_check_list.abc_b['Meal2']==1.toString() && return_check_list.abc_b['Meal3']==1.toString())
    {
      print("object");

      await FirebaseFirestore.instance
          .collection("users")
          .doc(user?.uid)
          .update({
        'b_check': 1,
      });

    }
    if(return_check_list.abc_l['Meal1']==1.toString() && return_check_list.abc_l['Meal2']==1.toString() && return_check_list.abc_l['Meal3']==1.toString())
    {

      await FirebaseFirestore.instance
          .collection("users")
          .doc(user?.uid)
          .update({
        'l_check': 1,
      });

    }
    if(return_check_list.abc_d['Meal1']==1.toString() && return_check_list.abc_d['Meal2']==1.toString() && return_check_list.abc_d['Meal3']==1.toString())
    {

      await FirebaseFirestore.instance
          .collection("users")
          .doc(user?.uid)
          .update({
        'd_check': 1,
      });

    }

  }

  @override
  Widget build(BuildContext context) {
    getUserProfileData();
    update_check_data();
    // print("asddd");
    return initWidget();
  }

  Widget initWidget() {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Diet Chart"),
        backgroundColor: Color(0xff9f72fb),
      ),
      // backgroundColor: Colors.red,

      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                // children: const [
                //   // Icon(Icons.menu,color:Colors.white,size: 20),
                // ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: Center(
                child: Wrap(
                  spacing: 20.0,
                  runSpacing: 20.0,
                  children: [
                    SizedBox(
                      width: 340.0,
                      height: 170.0,
                      child: Card(
                        color: Color.fromARGB(100, 196,163,251),
                        elevation: 20.0,

                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        // child: Center(

                          child: Padding(
                            padding:
                            const EdgeInsets.only(top: 12, left: 5),

                            child: Column(
                              children:  [
                                Text("Breakfast"),
                                Container(margin: EdgeInsets.only(top:20),),
                                Container(
                                  child: return_check_list.abc_b['Meal1']!=1.toString()
                                  ?Text("${userProfileData_B['Meal1']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                    :Text("${userProfileData_B['Meal1']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                        decoration: TextDecoration.lineThrough
                                      )),
                                ),

                                Container(
                                  child: return_check_list.abc_b['Meal2']!=1.toString()
                                      ?Text("${userProfileData_B['Meal2']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_B['Meal2']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),
                                Container(
                                  child: return_check_list.abc_b['Meal3']!=1.toString()
                                      ?Text("${userProfileData_B['Meal3']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_B['Meal3']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),
                              ],
                            ),
                          ),

                      ),
                    ),
                    SizedBox(
                      width: 340.0,
                      height: 170.0,
                      child: Card(
                        color: Color.fromARGB(100, 196,163,251),
                        elevation: 20.0,

                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Padding(
                            padding:
                            const EdgeInsets.only(top: 12, left: 5),

                            child: Column(
                              children:  [
                                Text("Lunch"),
                                Container(margin: EdgeInsets.only(top:20),),
                                Container(
                                  child: return_check_list.abc_l['Meal1']!=1.toString()
                                      ?Text("${userProfileData_L['Meal1']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_L['Meal1']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),

                                Container(
                                  child: return_check_list.abc_l['Meal2']!=1.toString()
                                      ?Text("${userProfileData_L['Meal2']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_L['Meal2']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),
                                Container(
                                  child: return_check_list.abc_l['Meal3']!=1.toString()
                                      ?Text("${userProfileData_L['Meal3']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_L['Meal3']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width:340.0,
                      height: 170.0,
                      child: Card(
                        color: Color.fromARGB(100, 196,163,251),
                        elevation: 20.0,

                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Padding(
                            padding:
                            const EdgeInsets.only(top: 12, left: 5),

                            child: Column(
                              children:  [
                                Text("Dinner"),
                                Container(margin: EdgeInsets.only(top:20),),
                                Container(
                                  child: return_check_list.abc_d['Meal1']!=1.toString()
                                      ?Text("${userProfileData_D['Meal1']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_D['Meal1']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),

                                Container(
                                  child: return_check_list.abc_d['Meal2']!=1.toString()
                                      ?Text("${userProfileData_D['Meal2']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_D['Meal2']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),
                                Container(
                                  child: return_check_list.abc_d['Meal3']!=1.toString()
                                      ?Text("${userProfileData_D['Meal3']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                      :Text("${userProfileData_D['Meal3']}".toUpperCase(),
                                      // textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          decoration: TextDecoration.lineThrough
                                      )),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),

    );
  }
}
class diet_item_list
{

  static var abc_b = userProfileData_B;
  static var abc_l = userProfileData_L;
  static var abc_d = userProfileData_D;

}
