import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
// import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/login.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:tflite_image_classification/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class USettings extends StatefulWidget {
  const USettings({Key? key}) : super(key: key);

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<USettings> {
  final _auth = FirebaseAuth.instance;

  // string for displaying the error Message
  String? errorMessage;

  // our form key
  final _formKey = GlobalKey<FormState>();
  // editing Controller
  final nameEditingController = new TextEditingController();
  final confirmOLDPasswordEditingController = new TextEditingController();
  final passwordEditingController = new TextEditingController();
  final confirmPasswordEditingController = new TextEditingController();
  final weightEditingController = new TextEditingController();
  final heightEditingController = new TextEditingController();
  final ageEditingController = new TextEditingController();
  final genderEditingController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    //first name field
    final nameField = TextFormField(
        autofocus: false,
        controller: nameEditingController,
        keyboardType: TextInputType.name,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{3,}$');
          if (value!.isEmpty) {
            return ("Username cannot be Empty");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid username(Min. 3 Character)");
          }
          return null;
        },
        onSaved: (value) {
          nameEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.account_circle, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Enter new username",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));

    final confirmOLDPasswordField = TextFormField(
        autofocus: false,
        controller: confirmOLDPasswordEditingController,
        obscureText: true,
        validator: (value) {
          if (confirmPasswordEditingController.text !=
              passwordEditingController.text) {
            return "Password don't match";
          }
          return null;
        },
        onSaved: (value) {
          confirmPasswordEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.vpn_key, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Please enter your old password",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));
    //password field
    final passwordField = TextFormField(
        autofocus: false,
        controller: passwordEditingController,
        obscureText: true,
        validator: (value) {
          RegExp regex = new RegExp(r'^.{6,}$');
          if (value!.isEmpty) {
            return ("Password is required for login");
          }
          if (!regex.hasMatch(value)) {
            return ("Enter Valid Password(Min. 6 Character)");
          }
        },
        onSaved: (value) {
          passwordEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.vpn_key, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Enter New Password",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));

    //confirm password field
    final confirmPasswordField = TextFormField(
        autofocus: false,
        controller: confirmPasswordEditingController,
        obscureText: true,
        validator: (value) {
          if (confirmPasswordEditingController.text !=
              passwordEditingController.text) {
            return "Password don't match";
          }
          return null;
        },
        onSaved: (value) {
          confirmPasswordEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.vpn_key, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Confirm New Password",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));
//confirm password field
    final weightField = TextFormField(
        autofocus: false,
        controller: weightEditingController,
        keyboardType: TextInputType.number,
        obscureText: false,
        validator: (value) {
          if (value!.isEmpty) {
            return ("Please enter Weight");
          }
          return null;
        },
        onSaved: (value) {
          confirmPasswordEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.line_weight, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Updated Weight in KGs",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));
    //confirm password field
    final heightField = TextFormField(
        autofocus: false,
        controller: heightEditingController,
        keyboardType: TextInputType.number,
        obscureText: false,
        validator: (value) {
          if (value!.isEmpty) {
            return ("Please enter Height");
          }
          return null;
        },
        onSaved: (value) {
          confirmPasswordEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.arrow_upward, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Updated Height in Inches",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));
    //confirm password field
    final ageField = TextFormField(
        autofocus: false,
        controller: ageEditingController,
        keyboardType: TextInputType.number,
        obscureText: false,
        validator: (value) {
          if (value!.isEmpty) {
            return ("Please enter Age");
          }
          return null;
        },
        onSaved: (value) {
          ageEditingController.text = value!;
        },
        textInputAction: TextInputAction.done,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.trending_up, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Updated Age",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));

    final genderField = TextFormField(
        autofocus: false,
        controller: genderEditingController,
        keyboardType: TextInputType.name,
        obscureText: false,
        validator: (value) {
          if (value!.isEmpty) {
            return ("Please select your Gender");
          }
          if (value != 'M' && value != 'F') {
            print(value);
            return ("Please Enter 'M' for Male and 'F' for Female");
          }
          return null;
        },
        onSaved: (value) {
          genderEditingController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          fillColor: Color(0xffe4d6fb),
          filled: true,
          prefixIcon: Icon(Icons.male, color: Color(0xff8c54fb)),
          contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          hintText: "Update Gender",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50),
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xff8c54fb), width: 0.7),
            borderRadius: BorderRadius.circular(25.0),
          ),
        ));

    //signup button
    final signUpButton = Material(
      elevation: 5,
      borderRadius: BorderRadius.circular(30),
      color: Color(0xff9f72fb),
      child: MaterialButton(
          padding: EdgeInsets.fromLTRB(20, 15, 20, 15),
          // minWidth: MediaQuery.of(context).size.width,
          minWidth: 180,
          onPressed: () {
            postDetailsToFirestore();
          },
          child: const Text(
            "Update",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: Colors.white),
          )),
    );

    return Scaffold(
      // backgroundColor: Colors.blue,
      appBar: AppBar(
        title: const Text("Settings"),
        backgroundColor: Color(0xff9f72fb),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            // color: Colors.pink,
            // color: Colors.red,
            padding: EdgeInsets.only(left: 20, right: 20),
            // child: Padding(
            //   padding: const EdgeInsets.all(20.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                      // margin: EdgeInsets.all(0),
                      // height: 80,
                      // decoration: const BoxDecoration(
                      //   borderRadius: BorderRadius.only(bottomLeft: Radius.circular(90)),
                      //   color:Color(0xffaabbcc),
                      //   gradient: LinearGradient(
                      //       colors:[Color(0xffe4d6fb),(Color(0xffe4d6fb))],
                      //       begin:Alignment.topCenter,
                      //       end: Alignment.bottomCenter
                      //   ),
                      // ),
                      ),
                  SizedBox(
                    height: 15,
                  ),
                  nameField,
                  SizedBox(
                    height: 15,
                  ),
                  confirmOLDPasswordField,
                  SizedBox(height: 15),
                  passwordField,
                  SizedBox(height: 15),
                  confirmPasswordField,
                  SizedBox(height: 15),
                  weightField,
                  SizedBox(height: 15),
                  genderField,
                  SizedBox(height: 15),
                  heightField,
                  SizedBox(height: 15),
                  ageField,
                  SizedBox(height: 40),
                  signUpButton,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  postDetailsToFirestore() async {
    print("qwe");
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    User? user = _auth.currentUser;
    print(user?.uid);

    var response = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo: user?.uid)
        .get();

    UserModel userModel = UserModel();

    // writing all the values
    userModel.email = user!.email;
    userModel.uid = user.uid;
    userModel.name = nameEditingController.text;
    userModel.age = int.parse(ageEditingController.text);
    userModel.weight = double.parse(weightEditingController.text);
    userModel.height = double.parse(heightEditingController.text);
    userModel.password = confirmPasswordEditingController.text;
    userModel.cp_check = 1;
    userModel.gender = genderEditingController.text;

    if (confirmOLDPasswordEditingController.text ==
        response.docs[0]['password']) {

      await firebaseFirestore.collection("users").doc(user.uid).update({
        'name': userModel.name,
        'password': userModel.password,
        'weight': userModel.weight,
        'height': userModel.height,
        'gender': userModel.gender,
        'age': userModel.age
      });
      // .set(userModel.toMap());
      Fluttertoast.showToast(msg: "Information Updated successfully");
      Fluttertoast.showToast(msg: "Please Login Again");

      Navigator.pushAndRemoveUntil(
          (context),
          MaterialPageRoute(builder: (context) => LoginScreen()),
          (route) => false);
    }
    else
      {
        Fluttertoast.showToast(msg: "Enter Correct Old Password");

      }
  }
}
