import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/signup.dart';
import 'package:tflite_image_classification/login.dart';
import 'package:tflite_image_classification/loadingPage1.dart';
import 'settings.dart';
import 'user_model.dart';

class SelectTrainer extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<SelectTrainer> {
  FirebaseAuth auth = FirebaseAuth.instance;
  User? user;
  Map userProfileData = {'username': '', 'gender': '', 'age': ''};
  Future<void> getUserProfileData() async {
    user = auth.currentUser;
    var response = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo: user?.uid)
        .get();

    print(response.docs[0]['age']);

    userProfileData['username'] = response.docs[0]['name'];
    userProfileData['gender'] = response.docs[0]['gender'];
    userProfileData['age'] = response.docs[0]['age'];

    try {} on FirebaseException catch (e) {
      print(e);
    } catch (error) {
      print(error);
    }
  }

  final Stream<QuerySnapshot> users =
      FirebaseFirestore.instance.collection('users').snapshots();



  @override
  Widget build(BuildContext context) {
    // getUserProfileData();

    return initWidget();
  }

  Widget initWidget() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Select Trainer"),
        backgroundColor: Color(0xff9f72fb),
      ),
      // body: ListView.builder(
      //     itemCount: 3,
      //     itemBuilder: (context, index) {
      //       return Container(
      //         margin: EdgeInsets.only(top: 12, left: 10, right: 10),
      //         child: ListTile(
      //           shape: const RoundedRectangleBorder(
      //               side: BorderSide(color: Colors.purple),
      //               borderRadius: BorderRadius.all(Radius.circular(40))),
      //           tileColor: Color(0xffe4d6fb),
      //           leading: const CircleAvatar(
      //             child: Icon(
      //               Icons.person,
      //               color: Colors.purple,
      //             ),
      //             backgroundColor: Colors.white,
      //           ),
      //           title: Text("${userProfileData['username']}".toUpperCase()),
      //           subtitle: Text("${userProfileData['gender']}".toUpperCase()),
      //           trailing: Text("${userProfileData['age']}"),
      //         ),
      //       );
      //     }),
      body: Container(
        height: 250,
        width: 500,
        // color: Colors.purple,

        child: StreamBuilder<QuerySnapshot>(
          stream: users,
          builder: (
            BuildContext context,
            AsyncSnapshot<QuerySnapshot> snapshot,
          ) {
            if (snapshot.hasError) {
              return Text("Something was wrong");
            }
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text("Loading");
            }
            final data = snapshot.requireData;

            return ListView.builder(
              itemCount: data.size,
              itemBuilder: (context,index)
              {
                return
                  data.docs[index]['cp_check']==2
                  ?Container(
                  margin: EdgeInsets.only(top: 12, left: 10, right: 10),
                  child: ListTile(
                    shape: const RoundedRectangleBorder(
                        side: BorderSide(color: Colors.purple),
                        borderRadius: BorderRadius.all(Radius.circular(40))),
                    tileColor: Color(0xffe4d6fb),
                    leading: const CircleAvatar(
                      child: Icon(
                        Icons.person,
                        color: Colors.purple,
                      ),
                      backgroundColor: Colors.white,
                    ),
                    title: Text("${data.docs[index]['name']}".toUpperCase()),
                    subtitle: Text("${data.docs[index]['gender']}".toUpperCase()),
                    trailing: Text("${data.docs[index]['age']}"),
                  ),
                )
                :Container();
              },
            );
          },
        ),
      ),
    );
  }
}
