// ignore_for_file: unrelated_type_equality_checks

import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite/tflite.dart';
import 'chart.dart';

const kModelName = "food-classification-fyp";

var copy_b = diet_item_list.abc_b;
var copy_l = diet_item_list.abc_l;
var copy_d = diet_item_list.abc_d;


Map check_list_b = {'Meal1':'','Meal2': '','Meal3':''};
Map check_list_l = {'Meal1':'','Meal2': '','Meal3':''};
Map check_list_d = {'Meal1':'','Meal2': '','Meal3':''};


class TfliteModel extends StatefulWidget {
  const TfliteModel({Key? key}) : super(key: key);

  @override
  _TfliteModelState createState() => _TfliteModelState();
}

class _TfliteModelState extends State<TfliteModel> {


  late File _image;
  late List _results;
  bool check = false;
  bool imageSelect=false;


  @override
  void initState()
  {
    super.initState();
    loadModel();
  }
  Future loadModel()
  async {
    Tflite.close();
    String res;
    res=(await Tflite.loadModel(model: "assets/model.tflite",labels: "assets/labels.txt"))!;
    print("Models loading status: $res");
  }

  Future imageClassification(File image)
  async {
    final List? recognitions = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 1,
      threshold: 0.05,
      imageMean: 127.5,
      imageStd: 127.5,
    );
    setState(() {
      _results=recognitions!;
      _image=image;
      print(recognitions);
      // model = _model as FirebaseCustomModel?;
      // print(model);
      imageSelect=true;
      // print(_results[0]);
      // print(recognitions);
    });
  }
  int gg = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Image Classification"),
        backgroundColor: Color(0xff9f72fb),
      ),
      body: ListView(
        children: [
          (imageSelect)?Container(

            margin: const EdgeInsets.only(top: 100,bottom: 20),
            child:
              Image.file(_image,height: 300,),
              // const Text("Scan unsuccessful"):

            // color: Colors.red,


          ):Container(
            color: Color.fromARGB(100, 196,163,251),
            height: 180,
            margin: const EdgeInsets.only(top:200,left: 60,right: 60),
              child: Column(
                children:<Widget> [
                  ListTile(
                    title: const Text('Scan BreakFast', style: TextStyle(fontSize: 20,color: Colors.purple)),
                    leading: Radio(
                      value: 1,
                      groupValue: gg,
                      onChanged: (newValue) {
                        setState(() {
                          gg = 1;
                        });
                      },
                    ),
                  ),
                  ListTile(
                    title: const Text('Scan Lunch',style: TextStyle(fontSize: 20,color: Colors.purple)),
                    leading: Radio(
                      value: 2,
                      groupValue: gg,
                      onChanged: (newValue) {
                        setState(() {
                          gg = 2;
                        });
                      },
                    ),
                  ),
                  ListTile(
                    title: const Text('Scan Dinner',style: TextStyle(fontSize: 20,color: Colors.purple)),
                    leading: Radio(
                      value: 3,
                      groupValue: gg,
                      onChanged: (newValue) {
                        setState(() {
                          gg = 3;
                        });
                      },
                    ),
                  ),

                ],
              ),
          ),
          SingleChildScrollView(
            child: Column(
              children: (imageSelect)?_results.map((result)
              {
                print(result['confidence']);
                print(copy_b);
                // print(check_list);
                if(result['confidence']<0.5)
                  {
                    result['label'] = "Please Rescan the image";
                    check = true;
                  }
                print(gg);
                if(gg==1 && result['label']==copy_b['Meal1'] || result['label']==copy_b['Meal2'] ||result['label']==copy_b['Meal3'])
                  {
                    if(result['label']==copy_b['Meal1'])
                      {
                        check_list_b['Meal1'] = '1';
                      }
                    else if(result['label']==copy_b['Meal2'])
                      {
                        check_list_b['Meal2'] = '1';
                      }
                    else
                      {
                        check_list_b['Meal3'] = '1';
                      }
                      return Card(
                        child: Container(
                          margin: EdgeInsets.all(10),
                          child: Text(
                            "${result['label']} Approved",
                            style: const TextStyle(color: Colors.green,
                                fontSize: 20),
                          ),
                        ),
                      );
                  }
                else {
                  if(gg==2 && result['label']==copy_l['Meal1'] || result['label']==copy_l['Meal2'] ||result['label']==copy_l['Meal3'])
                {
                  if(result['label']==copy_l['Meal1'])
                  {
                    check_list_l['Meal1'] = '1';
                  }
                  else if(result['label']==copy_l['Meal2'])
                  {
                    check_list_l['Meal2'] = '1';
                  }
                  else
                  {
                    check_list_l['Meal3'] = '1';
                  }
                  return Card(
                    child: Container(
                      margin: EdgeInsets.all(10),
                      child: Text(
                        "${result['label']} Approved",
                        style: const TextStyle(color: Colors.green,
                            fontSize: 20),
                      ),
                    ),
                  );
                }
                else if(gg==3 && result['label']==copy_d['Meal1'] || result['label']==copy_d['Meal2'] ||result['label']==copy_d['Meal3'])
                {
                  if(result['label']==copy_d['Meal1'])
                  {
                    check_list_d['Meal1'] = '1';
                  }
                  else if(result['label']==copy_l['Meal2'])
                  {
                    check_list_d['Meal2'] = '1';
                  }
                  else
                  {
                    check_list_d['Meal3'] = '1';
                  }
                  return Card(
                    child: Container(
                      margin: EdgeInsets.all(10),
                      child: Text(
                        "${result['label']} Approved",
                        style: const TextStyle(color: Colors.green,
                            fontSize: 20),
                      ),
                    ),
                  );
                }
                }
                print(check_list_b);
                return Card(
                  child: Container(
                    margin: EdgeInsets.all(10),
                    child: const Text(
                      "MEAL NOT APPROVED!\n" + "Scan prescribed meal again" ,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.red,
                          fontSize: 15),
                    ),
                  ),
                );
              }).toList():[]

            ),
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: pickImage,
        tooltip: "Pick Image",
        child: const Icon(Icons.camera),
        backgroundColor: Color(0xff9f72fb),
      ),
    );
  }
  Future pickImage()
  async {
    final ImagePicker _picker = ImagePicker();
    final XFile? pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
    );
    File image=File(pickedFile!.path);
    imageClassification(image);
  }
}
class return_check_list
{
  static var abc_b = check_list_b;
  static var abc_l = check_list_l;
  static var abc_d = check_list_d;

}
