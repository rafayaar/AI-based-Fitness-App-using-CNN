import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/signup.dart';
import 'package:tflite_image_classification/login.dart';
import 'package:tflite_image_classification/loadingPage1.dart';
import 'settings.dart';

class About extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  Widget initWidget() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("About Us"),
        backgroundColor: Color(0xff9f72fb),
      ),
      // backgroundColor: Colors.red,

      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                // children: const [
                //   // Icon(Icons.menu,color:Colors.white,size: 20),
                // ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: Center(
                child: Wrap(
                  spacing: 20.0,
                  runSpacing: 20.0,
                  children: [
                        SizedBox(
                          width: 200.0,
                          height: 180.0,
                          child: Card(
                            color: Color.fromARGB(100, 196,163,251),
                            elevation: 20.0,

                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Center(
                              child: Padding(
                                padding:
                                const EdgeInsets.only(top: 20, left: 5),
                                child: Column(
                                  children: const [
                                    Icon(Icons.person,size: 80),
                                    SizedBox(height: 10.0),
                                    Text("Rafay Mahmood",
                                        // textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                    SizedBox(
                      width: 200.0,
                      height: 180.0,
                      child: Card(
                        color: Color.fromARGB(100, 196,163,251),
                        elevation: 20.0,

                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Padding(
                            padding:
                            const EdgeInsets.only(top: 20, left: 5),
                            child: Column(
                              children: const [
                                Icon(Icons.person,size: 80),
                                SizedBox(height: 10.0),
                                Text("Muneeb Ahmad",
                                    // textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20.0,
                                    ))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 200.0,
                      height: 180.0,
                      child: Card(
                        color: Color.fromARGB(100, 196,163,251),
                        elevation: 20.0,

                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Padding(
                            padding:
                            const EdgeInsets.only(top: 20, left: 5),
                            child: Column(
                              children: const [
                                Icon(Icons.person,size: 80),
                                SizedBox(height: 10.0),
                                Text("Arooj Fatima",
                                    // textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20.0,
                                    ))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
