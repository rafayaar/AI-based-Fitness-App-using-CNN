class UserModel{
  String? uid;
  String? name;
  String? email;
  String? password;
  String? contact;
  double? weight;
  double? height;
  int? age;
  int? cp_check;
  String? gender;

  String?b_meal1;
  String?b_meal2;
  String?b_meal3;

  String?l_meal1;
  String?l_meal2;
  String?l_meal3;

  String?d_meal1;
  String?d_meal2;
  String?d_meal3;

  String?b_check;
  String? l_check;
  String?d_check;

  UserModel({
    this.uid,
    this.name,
    this.email,
    this.password,
    this.contact,
    this.weight,
    this.height,
    this.age,
    this.cp_check,
    this.gender,
    this.b_meal1,
    this.b_meal2,
    this.b_meal3,
    this.l_meal1,
    this.l_meal2,
    this.l_meal3,
    this.d_meal1,
    this.d_meal2,
    this.d_meal3,
    this.b_check,
    this.l_check,
    this.d_check



  });

  factory UserModel.fromMap(map){
        return UserModel(
        uid : map['uid'],
        name : map['name'],
        contact: map['contact'],
        email : map['email'],
        password : map['password'],
        weight : map['weight'],
        height : map['height'],
        age : map['age'],
            cp_check : map['cp_check'],
          gender: map['gender'],
          b_meal1: map['b_meal1'],
          b_meal2: map['b_meal2'],
          b_meal3: map['b_meal3'],

          l_meal1: map['l_meal1'],
          l_meal2: map['l_meal2'],
          l_meal3: map['l_meal3'],

          d_meal1: map['d_meal1'],
          d_meal2: map['d_meal2'],
          d_meal3: map['d_meal3'],

          b_check: map['b_check'],
          l_check: map['l_check'],
          d_check: map['d_check'],
        );
      }
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name':name,
      'email': email,
      'contact': contact,
      'password': password,
      'weight' :weight,
      'height':height,
      'age':age,
      'cp_check' : cp_check,
      'gender': gender,
      'b_meal1':b_meal1,
      'b_meal2':b_meal2,
      'b_meal3':b_meal3,
      'l_meal1':l_meal1,
      'l_meal2':l_meal2,
      'l_meal3':l_meal3,
      'd_meal1':d_meal1,
      'd_meal2':d_meal1,
      'd_meal3':d_meal1,
      'b_check' :b_check,
      'l_check' :l_check,
      'd_check':d_check
    };
  }
}