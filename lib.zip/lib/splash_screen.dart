import 'dart:async';
import 'package:flutter/material.dart';
import 'package:tflite_image_classification/loadingPage1.dart';
import 'login.dart';

// void main() {
//   runApp(const SplashScreen());
// }

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<SplashScreen> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTime();
  }

  startTime() async {
    var duration = const Duration(seconds: 4);
    return Timer(duration, route);
  }

  route() {
    Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (context) =>  const HomePage()
    ));
  }

  @override
  Widget build(BuildContext context) {
    return initWidget(context);
  }

  Widget initWidget(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
                color: Color(0xffaabbcc),
                gradient: LinearGradient(colors: [(Color(0xffe4d6fb)), Color(0xffe4d6fb)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter
                )
            ),
          ),
          Center(
            child: SizedBox(
              child: Image.asset("assets/images/myLogo.png"),
              height: 90,
              width: 90,
            ),
          )
        ],
      ),
    );
  }
}