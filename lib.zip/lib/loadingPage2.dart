import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:tflite_image_classification/homescreen.dart';
import 'package:tflite_image_classification/login.dart';
import "signup.dart";


class LoadingScreen2 extends StatefulWidget {
  // final String abc = "";
  const LoadingScreen2({Key? key}) : super(key: key);
  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<LoadingScreen2> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    startTime();
  }
  startTime() async {
    var duration = const Duration(seconds: 3);
    return Timer(duration, route);
  }

  route() {
    Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (context) =>  RegistrationScreen()
    ));
  }

  @override
  Widget build(BuildContext context) {
    return initWidget(context);
  }

  Widget initWidget(BuildContext context) {
    return const Scaffold(

      backgroundColor: Color(0xffe4d6fb),
      body: Center(
        child: SpinKitFadingCube(
          size: 50,
          color: Color(0xff8c54fb),
          duration: Duration(seconds: 2),
        ),
      ),
    );
  }
}