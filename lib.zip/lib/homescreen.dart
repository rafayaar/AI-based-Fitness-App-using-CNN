import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tflite_image_classification/TfliteModel.dart';
import 'package:tflite_image_classification/signup.dart';
import 'package:tflite_image_classification/login.dart';
import 'package:tflite_image_classification/loadingPage1.dart';
import 'settings.dart';
import 'about.dart';
import 'chart.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'selectTrainer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login.dart';


class dashboard extends StatefulWidget
{
  // final String text;

  const dashboard({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => StartState();
}

class StartState extends State<dashboard>
{
  FirebaseAuth auth =  FirebaseAuth.instance;
  User? user;
  Map userProfileData = {'username':''};
  Future<void> getUserProfileData() async
  {

    user = auth.currentUser;
    var response = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo:user?.uid)
        .get();

    // print('asdasd');
    // print(user?.uid);
    // print(response.docs[0]['name']);

    userProfileData['username'] = response.docs[0]['name'];


    try {

    }on FirebaseException catch(e){
      print(e);
    }catch(error){
      print(error);
    }
    setState((){
      return;
    });
  }



  @override
  Widget build(BuildContext context) {
    // print(c_user);
    // print("object");
    getUserProfileData();
    return initWidget();
  }

  Widget initWidget() {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hello ${userProfileData['username']}'.toUpperCase()),
        backgroundColor: Color(0xff9f72fb),
      ),
      // backgroundColor: Colors.red,

      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                // children: const [
                //   // Icon(Icons.menu,color:Colors.white,size: 20),
                // ],
              ),

            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Center(
                child: Wrap(
                  spacing: 20.0,
                  runSpacing: 20.0,
                  children: [
                    GestureDetector(
                      onTap: () => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Chart()))
                      },
                      child: AbsorbPointer(
                        child: SizedBox(
                          width: 340.0,
                          height: 160.0,
                          child: Card(
                            color: Color.fromARGB(100, 196,163,251),
                            elevation: 20.0,

                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 30, left: 5),
                                child: Column(
                                  children: [
                                    Image.asset("assets/images/diet.png",
                                        width: 55.0),
                                    const SizedBox(height: 10.0),
                                    const Text("Diet Chart",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SelectTrainer()))
                      },
                      child: AbsorbPointer(
                        child: SizedBox(
                          width: 160.0,
                          height: 160.0,
                          child: Card(
                            color: Color.fromARGB(100, 196,163,251),
                            elevation: 20.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 20, left: 5),
                                child: Column(
                                  children: [
                                    Image.asset("assets/images/trainers.png",
                                        width: 55.0),
                                    const SizedBox(height: 8.0),
                                    const Text("Select the Trainer",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TfliteModel()))
                      },
                      child: AbsorbPointer(
                        child: SizedBox(
                          width: 160.0,
                          height: 160.0,
                          child: Card(
                            color: Color.fromARGB(100, 196,163,251),
                            elevation: 20.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),

                            ),
                            child: Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 30, left: 5),
                                child: Column(
                                  children: const [
                                    Icon(Icons.camera,size: 50),
                                    SizedBox(height: 10.0),
                                    Text("Scan Image",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => About()))
                      },
                      child: AbsorbPointer(
                          child: SizedBox(
                        width: 160.0,
                        height: 160.0,
                        child: Card(
                          color: Color.fromARGB(100, 196,163,251),
                          elevation: 20.0,

                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),

                          ),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 30, left: 5),
                              child: Column(
                                children: const [
                                  Icon(Icons.people_outline,size: 50),
                                  SizedBox(height: 10.0),
                                  Text("About",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                      ))
                                ],
                              ),
                            ),
                          ),
                        ),
                      )),
                    ),
                    GestureDetector(
                      onTap: () => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => USettings()))
                      },
                      child: AbsorbPointer(
                          child: SizedBox(
                            width: 160.0,
                            height: 160.0,
                            child: Card(
                              color: Color.fromARGB(100, 196,163,251),
                              elevation: 20.0,

                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),

                              ),
                              child: Center(
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 30, left: 5),
                                  child: Column(
                                    children: const [
                                      Icon(Icons.settings,size: 50),
                                      // Image.asset("assets/images/faq.png",
                                      //     width: 55.0),
                                      SizedBox(height: 10.0),
                                      Text("Settings",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20.0,
                                          ))
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          )),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: check,
        tooltip: "Pick Image",
        child: Icon(Icons.logout),
        backgroundColor: Color(0xff8c54fb),
      ),
    );
  }
  Future check() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushAndRemoveUntil(
        (context),
        MaterialPageRoute(builder: (context) => LoginScreen()),
            (route) => false);
    // Navigator.pushNamedAndRemoveUntil(context, "/LoginScreen", (Route<dynamic> route) => false);
  }
}
